sleep 1
passwd deck
echo "Ready to exit in 3 second."
sleep 3
