#!/bin/bash
echo "ready to install firefox."
flatpak install flathub org.mozilla.firefox -y
echo "Ready to exit in 3 second."
sleep 3
